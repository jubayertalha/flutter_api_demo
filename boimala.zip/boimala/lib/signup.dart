import 'package:flutter/material.dart';
import 'package:http/http.dart' as Http;

class Signup extends StatefulWidget{

  @override
  State<StatefulWidget> createState() {
    return SignupPageState();
  }

}

class SignupPageState extends State<Signup>{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(
          child: Text('Signup'),
        ),
      ),
    );
  }

}