import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:boimala/login.dart';
import 'package:boimala/home.dart';

void main() => runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Boimala',
    theme: ThemeData(
      primarySwatch: Colors.blue,
    ),
    home:Boimala(),
));

class Boimala extends StatefulWidget {

  @override
  State<StatefulWidget> createState() {
    return BoimalaState();
  }
}

class BoimalaState extends State<Boimala>{

  Timer _timer;
  int count = 4;
  String title = 'Boimala';

  isLogedIn() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('logedIn') ?? false;
  }

  setTimer(BuildContext context){
    _timer = new Timer.periodic(Duration(seconds: 1), (Timer timer)=> setState((){

      if(count==5){
        timer.cancel();
        Navigator.of(context).pushReplacement(MaterialPageRoute<Null>(
            builder: (BuildContext context){
              if(isLogedIn()==true){
                return Home();
              }else{
                return Login();
              }
            }
        ));
      }else{
        if(count.remainder(3)==1){
          title = 'Boimala.';
        }else if(count.remainder(3)==2){
          title = 'Boimala..';
        }else{
          title = 'Boimala...';
        }
        count++;
      }

    }));

  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  String getTitle(BuildContext context){
    if(count == 4) setTimer(context);
    return title;
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
        body: Container(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Icon(
                    Icons.book,
                    size: 45.0,
                ),
                Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text(
                    getTitle(context),
                    style: TextStyle(
                      fontSize: 24.0,
                      color: Colors.black,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
  }

}